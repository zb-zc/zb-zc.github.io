#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/ide.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/errno.h>
#include <linux/gpio.h>
#include <linux/cdev.h>
#include <linux/device.h>

#include <asm/mach/map.h>
#include <asm/uaccess.h>
#include <asm/io.h>

//#include <mach/gpio-exynos4.h>
//#include <plat/gpio-cfg.h> 


//LED: XEINT25/KP_ROW9/ALV_DBG21/GPX3_1(6-263)
#define LED_NUMBER           1
#define LED_NAME            "led"
#define LEDOFF 					0			/* 关灯 */
#define LEDON 					1			/* 开灯 */


struct led_dev{
    dev_t devid; //设备号
    struct cdev cdev;//cdev
    struct class *class; //为了生成设别节点的类
    struct device *device; //设备  
    int major;//主设备号 
    int minor;//次设备号 
    /* data */
};
struct led_dev led;

static int led_open(struct file *filp,char __user *buf,size_t cnt,loff_t *offt)
{
    filp->private_data = &led;
    return 0;
}
static ssize_t led_read(struct file *filp, char __user *buf, size_t cnt, loff_t *offt)
{
	return 0;
}
static ssize_t led_write(struct file *filp, const char __user *buf, size_t cnt, loff_t *offt)
{
    int retvalue;
	unsigned char databuf[1];
	unsigned char ledstat;

	retvalue = copy_from_user(databuf, buf, cnt);
	if(retvalue < 0) {
		printk("kernel write failed!\r\n");
		return -EFAULT;
	}

	ledstat = databuf[0];		/* 获取状态值 */

	if(ledstat == LEDON) {	
		gpio_set_value(EXYNOS4_GPX3(1),0);		/* 打开LED灯 */
	} else if(ledstat == LEDOFF) {
		gpio_set_value(EXYNOS4_GPX3(1),1);
	}
	return 0;
}
static int led_release(struct inode *inode, struct file *filp)
{
    filp->private_data = &led;
    return 0;
}
static struct file_operations led_fops = {
    .owner = THIS_MODULE,
    .open = led_open,
    .read = led_read,
    .write = led_write,
    .release = led_release,
};





static void __init led_init(void)
{
    /*********************************************************************************
    操作底层GPIO的方法
    ************************************************************************************/
    gpio_request(EXYNOS4_GPX3(1),"LED3");  
    s3c_gpio_cfgpin(EXYNOS4_GPX3(1),S3C_GPIO_OUTPUT);
    /*注册设备驱动*/
    /*1.创建设备号*/
    if(led.major){//如果定义了设备号
    led.devid = MKDEV(led.major,0);//将定义好的设备好转换为dev_t类型的设备号
    register_chrdev_region(led.devid,LED_NUMBER,LED_NAME); 
    } 
    else{//没有定义设备号
    alloc_chrdev_region(&led.devid,0,LED_NAME,LED_NAME);
    led.major = MAJOR(led.devid); //获得主设备号
    led.minor = MINOR(led.devid);//获得次设备号
    }
    printk("led major = %d,minor=%d\r\n",led.major,led.minor);
    /*2.初始化cdev*/
    led.cdev.owner = THIS_MODULE;
    cdev_init(&led.cdev,&led_fops);
    /*3.添加一个cdev*/
    cdev_add(&led.cdev,led.devid,LED_NUMBER);
    /*4.创建类 */
    led.class = class_create(THIS_MODULE,LED_NAME);
    /*5.创建设备*/
    led.device = device_create(&led.class,NULL,led.devid,NULL,LED_NAME);

}

static void __exit led_exit(void)
{
    cdev_del(&led.cdev);
    unregister_chrdev_region(led.devid,LED_NUMBER);
    device_destroy(led.class,led.devid);
    class_destroy(led.class);
}

module_init(led_init);
module_exit(led_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("zhaobo1997work@163.com");

